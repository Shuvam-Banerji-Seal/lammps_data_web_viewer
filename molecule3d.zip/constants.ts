
export const ATOM_COLORS: Record<number, string> = {
  1: "#FFFFFF",   // H  - Hydrogen (White)
  2: "#D9FFFF",   // He - Helium (Cyan-White)
  3: "#CC80FF",   // Li - Lithium (Violet)
  4: "#C2FF00",   // Be - Beryllium (Yellow-Green)
  5: "#FFB5B5",   // B  - Boron (Pinkish)
  6: "#909090",   // C  - Carbon (Grey)
  7: "#3050F8",   // N  - Nitrogen (Blue)
  8: "#FF0D0D",   // O  - Oxygen (Red)
  9: "#90E050",   // F  - Fluorine (Green)
  10: "#B3E3F5",  // Ne - Neon (Cyan)
  11: "#AB5CF2",  // Na - Sodium (Violet)
  12: "#8AFF00",  // Mg - Magnesium (Green)
  13: "#BFA6A6",  // Al - Aluminium (Grey-Pink)
  14: "#F0C8A0",  // Si - Silicon (Tan)
  15: "#FF8000",  // P  - Phosphorus (Orange)
  16: "#FFFF30",  // S  - Sulfur (Yellow)
  17: "#1FF01F",  // Cl - Chlorine (Green)
  18: "#80D1E3",  // Ar - Argon (Cyan)
  19: "#8F40D4",  // K  - Potassium (Violet)
  20: "#3DFF00",  // Ca - Calcium (Green)
  21: "#E6E6E6",  // Sc - Scandium
  22: "#BFC2C7",  // Ti - Titanium (Grey)
  23: "#A6A6AB",  // V  - Vanadium
  24: "#8A99C7",  // Cr - Chromium
  25: "#9C7AC7",  // Mn - Manganese
  26: "#E06633",  // Fe - Iron (Orange-Red)
  27: "#F090A0",  // Co - Cobalt
  28: "#50D050",  // Ni - Nickel (Green)
  29: "#C88033",  // Cu - Copper (Brown)
  30: "#7D80B0",  // Zn - Zinc (Slate)
  31: "#C28F8F",  // Ga - Gallium
  32: "#668F8F",  // Ge - Germanium
  33: "#BD80E3",  // As - Arsenic
  34: "#FFA100",  // Se - Selenium
  35: "#A62929",  // Br - Bromine (Dark Red)
  36: "#5CB8D1",  // Kr - Krypton
  37: "#702EB0",  // Rb - Rubidium
  38: "#00FF00",  // Sr - Strontium
  46: "#006985",  // Pd - Palladium
  47: "#C0C0C0",  // Ag - Silver
  48: "#FFD98F",  // Cd - Cadmium
  50: "#668080",  // Sn - Tin
  53: "#940094",  // I  - Iodine (Purple)
  54: "#429EB0",  // Xe - Xenon
  78: "#D0D0E0",  // Pt - Platinum
  79: "#FFD123",  // Au - Gold
  80: "#B8B8D0",  // Hg - Mercury
  82: "#575961",  // Pb - Lead
  92: "#008FFF",  // U  - Uranium
};

export const DEFAULT_ATOM_COLOR = "#FF00FF"; // Magenta for unknown

// Helper to guess element from mass
export const ELEMENT_DATA: { mass: number; symbol: string; name: string; number: number }[] = [
  { mass: 1.008, symbol: 'H', name: 'Hydrogen', number: 1 },
  { mass: 4.003, symbol: 'He', name: 'Helium', number: 2 },
  { mass: 6.941, symbol: 'Li', name: 'Lithium', number: 3 },
  { mass: 9.012, symbol: 'Be', name: 'Beryllium', number: 4 },
  { mass: 10.81, symbol: 'B', name: 'Boron', number: 5 },
  { mass: 12.01, symbol: 'C', name: 'Carbon', number: 6 },
  { mass: 14.01, symbol: 'N', name: 'Nitrogen', number: 7 },
  { mass: 16.00, symbol: 'O', name: 'Oxygen', number: 8 },
  { mass: 19.00, symbol: 'F', name: 'Fluorine', number: 9 },
  { mass: 20.18, symbol: 'Ne', name: 'Neon', number: 10 },
  { mass: 22.99, symbol: 'Na', name: 'Sodium', number: 11 },
  { mass: 24.31, symbol: 'Mg', name: 'Magnesium', number: 12 },
  { mass: 26.98, symbol: 'Al', name: 'Aluminium', number: 13 },
  { mass: 28.09, symbol: 'Si', name: 'Silicon', number: 14 },
  { mass: 30.97, symbol: 'P', name: 'Phosphorus', number: 15 },
  { mass: 32.07, symbol: 'S', name: 'Sulfur', number: 16 },
  { mass: 35.45, symbol: 'Cl', name: 'Chlorine', number: 17 },
  { mass: 39.95, symbol: 'Ar', name: 'Argon', number: 18 },
  { mass: 39.10, symbol: 'K', name: 'Potassium', number: 19 },
  { mass: 40.08, symbol: 'Ca', name: 'Calcium', number: 20 },
  { mass: 47.87, symbol: 'Ti', name: 'Titanium', number: 22 },
  { mass: 55.85, symbol: 'Fe', name: 'Iron', number: 26 },
  { mass: 63.55, symbol: 'Cu', name: 'Copper', number: 29 },
  { mass: 107.9, symbol: 'Ag', name: 'Silver', number: 47 },
  { mass: 196.97, symbol: 'Au', name: 'Gold', number: 79 },
];


export const EXAMPLE_C60 = `# C60 Fullerene with bonding topology
# Generated with proper C-C bonds (1.3-1.5 Å)

60 atoms
90 bonds

1 atom types
1 bond types

-10.0 4.9 xlo xhi
-10.3 4.7 ylo yhi
-8.9 5.8 zlo zhi

Masses

1 12.011 # Carbon

Atoms # full

   1 1 6 0.0     -1.18100     -5.21900      0.52300
   2 1 6 0.0     -1.52700     -4.21900      1.44900
   3 1 6 0.0     -2.92600     -4.22500      1.59300
   4 1 6 0.0     -2.50700     -6.25200     -1.26100
   5 1 6 0.0     -1.45700     -6.03500     -2.17100
   6 1 6 0.0     -0.25700     -5.40600     -1.73600
   7 1 6 0.0     -0.12000     -4.99900     -0.39800
   8 1 6 0.0     -0.81400     -2.98900      1.46600
   9 1 6 0.0      0.23600     -2.77100      0.55600
  10 1 6 0.0      0.58500     -3.78100     -0.38100
  11 1 6 0.0     -3.62800     -2.99800      1.75400
  12 1 6 0.0     -2.92400     -1.78100      1.77000
  13 1 6 0.0     -3.72100     -6.04300     -1.93900
  14 1 6 0.0     -5.36500     -3.80100      0.22800
  15 1 6 0.0     -4.84200     -2.78800      1.07700
  16 1 6 0.0     -2.02300     -5.69500     -3.41300
  17 1 6 0.0     -3.42300     -5.69800     -3.27000
  18 1 6 0.0      0.88300     -3.43600     -1.71100
  19 1 6 0.0      0.36500     -4.44000     -2.54800
  20 1 6 0.0     -5.93400     -3.46000     -1.01200
  21 1 6 0.0     -5.58900     -4.46100     -1.93900
  22 1 6 0.0     -3.70300     -0.82000      1.10200
  23 1 6 0.0     -4.88800     -1.44300      0.67100
  24 1 6 0.0     -0.21000     -4.09300     -3.80200
  25 1 6 0.0     -1.39500     -4.71600     -4.23200
  26 1 6 0.0     -5.28600     -4.11200     -3.28300
  27 1 6 0.0     -4.21000     -4.72600     -3.94500
  28 1 6 0.0     -5.46300     -1.09600     -0.58200
  29 1 6 0.0     -5.98100     -2.10000     -1.42000
  30 1 6 0.0     -1.67500      0.16200      0.13900
  31 1 6 0.0     -3.07500      0.15900      0.28200
  32 1 6 0.0      0.49100     -1.07500     -1.19200
  33 1 6 0.0      0.83700     -2.07600     -2.11800
  34 1 6 0.0     -2.17400     -3.75500     -4.90100
  35 1 6 0.0     -3.58900     -3.75900     -4.75600
  36 1 6 0.0     -0.28600     -0.11400     -1.86100
  37 1 6 0.0     -1.37700      0.50700     -1.19200
  38 1 6 0.0     -3.64200      0.49900     -0.96000
  39 1 6 0.0     -4.84100     -0.13100     -1.39500
  40 1 6 0.0     -5.68300     -1.75500     -2.74900
  41 1 6 0.0     -5.33300     -2.76500     -3.68600
  42 1 6 0.0     -4.97800     -0.53700     -2.73300
  43 1 6 0.0     -2.59100      0.71600     -1.87000
  44 1 6 0.0     -4.81200     -5.42200     -1.26900
  45 1 6 0.0     -4.67400     -5.01600      0.07000
  46 1 6 0.0     -3.44500     -5.22800      0.75600
  47 1 6 0.0     -2.36700     -5.84200      0.09400
  48 1 6 0.0     -1.50900     -1.77700      1.62500
  49 1 6 0.0     -0.88800     -0.81100      0.81400
  50 1 6 0.0      0.18900     -1.42500      0.15200
  51 1 6 0.0     -4.28400     -2.54700     -4.59600
  52 1 6 0.0     -3.91700     -0.31700     -3.65400
  53 1 6 0.0     -3.57100     -1.31700     -4.58000
  54 1 6 0.0     -1.47000     -2.53800     -4.88400
  55 1 6 0.0     -0.25600     -2.74800     -4.20700
  56 1 6 0.0     -2.17200     -1.31200     -4.72400
  57 1 6 0.0      0.26800     -1.73500     -3.35800
  58 1 6 0.0     -0.42400     -0.52000     -3.20100
  59 1 6 0.0     -2.73100      0.30600     -3.22500
  60 1 6 0.0     -1.65200     -0.30800     -3.88600

Bonds

   1 1    1    2
   2 1    1    7
   3 1    1   47
   4 1    2    3
   5 1    2    8
   6 1    3   11
   7 1    3   46
   8 1    4    5
   9 1    4   13
  10 1    4   47
  11 1    5    6
  12 1    5   16
  13 1    6    7
  14 1    6   19
  15 1    7   10
  16 1    8    9
  17 1    8   48
  18 1    9   10
  19 1    9   50
  20 1   10   18
  21 1   11   12
  22 1   11   15
  23 1   12   22
  24 1   12   48
  25 1   13   17
  26 1   13   44
  27 1   14   15
  28 1   14   20
  29 1   14   45
  30 1   15   23
  31 1   16   17
  32 1   16   25
  33 1   17   27
  34 1   18   19
  35 1   18   33
  36 1   19   24
  37 1   20   21
  38 1   20   29
  39 1   21   26
  40 1   21   44
  41 1   22   23
  42 1   22   31
  43 1   23   28
  44 1   24   25
  45 1   24   55
  46 1   25   34
  47 1   26   27
  48 1   26   41
  49 1   27   35
  50 1   28   29
  51 1   28   39
  52 1   29   40
  53 1   30   31
  54 1   30   37
  55 1   30   49
  56 1   31   38
  57 1   32   33
  58 1   32   36
  59 1   32   50
  60 1   33   57
  61 1   34   35
  62 1   34   54
  63 1   35   51
  64 1   36   37
  65 1   36   58
  66 1   37   43
  67 1   38   39
  68 1   38   43
  69 1   39   42
  70 1   40   41
  71 1   40   42
  72 1   41   51
  73 1   42   52
  74 1   43   59
  75 1   44   45
  76 1   45   46
  77 1   46   47
  78 1   48   49
  79 1   49   50
  80 1   51   53
  81 1   52   53
  82 1   52   59
  83 1   53   56
  84 1   54   55
  85 1   54   56
  86 1   55   57
  87 1   56   60
  88 1   57   58
  89 1   58   60
  90 1   59   60
`;